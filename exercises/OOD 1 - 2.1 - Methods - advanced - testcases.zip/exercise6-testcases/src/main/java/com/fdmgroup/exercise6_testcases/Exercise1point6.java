package com.fdmgroup.exercise6_testcases;

public class Exercise1point6 {

	public int roverMove(int gridSize, String[] commands) {
		
		return 0;
	}


}
