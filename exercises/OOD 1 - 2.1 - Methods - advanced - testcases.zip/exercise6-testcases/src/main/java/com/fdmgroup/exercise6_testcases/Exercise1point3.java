package com.fdmgroup.exercise6_testcases;

public class Exercise1point3 {

	public String simpleEncoder(String string){
		return null;
	}

}
