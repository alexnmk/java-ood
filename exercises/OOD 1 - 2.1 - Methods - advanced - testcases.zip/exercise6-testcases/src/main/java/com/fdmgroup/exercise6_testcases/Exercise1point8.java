package com.fdmgroup.exercise6_testcases;

public class Exercise1point8 {

	public boolean validPassword(String password) {

		return false;
	}


}
