package com.fdmgroup.exercise6_testcases;

public class Exercise1point5 {

	public int[] rotateArray(int[] array, int numberOfRotations) {
		
		return null;
	}


}
