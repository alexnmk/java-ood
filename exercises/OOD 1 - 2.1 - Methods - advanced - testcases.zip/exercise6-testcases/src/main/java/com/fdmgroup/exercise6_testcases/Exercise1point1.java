package com.fdmgroup.exercise6_testcases;

import java.util.List;

public class Exercise1point1 {

	public List<Integer> primeNumbers(int highestNumber) {

		return null;
	}

}
