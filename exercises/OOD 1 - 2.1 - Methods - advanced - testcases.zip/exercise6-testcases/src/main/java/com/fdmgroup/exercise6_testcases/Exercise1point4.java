package com.fdmgroup.exercise6_testcases;

public class Exercise1point4 {

	public String encode(String text){
		return null;
	}
	

}
