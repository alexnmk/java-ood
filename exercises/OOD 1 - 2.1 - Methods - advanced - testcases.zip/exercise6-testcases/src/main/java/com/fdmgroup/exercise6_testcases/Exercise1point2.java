package com.fdmgroup.exercise6_testcases;

public class Exercise1point2 {

	public int[] bubbleSort(int[] array) {
		return null;
	}

}
