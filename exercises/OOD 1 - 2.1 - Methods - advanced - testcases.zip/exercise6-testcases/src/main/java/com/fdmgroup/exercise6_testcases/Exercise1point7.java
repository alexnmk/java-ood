package com.fdmgroup.exercise6_testcases;

public class Exercise1point7 {

	public boolean validPostcode(String postcode) {

		return false;
	}


}
