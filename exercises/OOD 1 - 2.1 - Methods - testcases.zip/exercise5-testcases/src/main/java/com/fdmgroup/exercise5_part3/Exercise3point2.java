package com.fdmgroup.exercise5_part3;

public class Exercise3point2 {

	public boolean arrayContains(String[] array, String string) {

		return false;
	}

}
