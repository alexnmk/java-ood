package com.fdmgroup.exercise5_part3;

public class Exercise3point7 {

	public boolean isAnagram(String string1, String string2) {
			
		return false;
	}

}
