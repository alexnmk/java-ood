package com.fdmgroup.exercise5_part3;

public class Exercise3point1 {

	public boolean leapYear(int year) {
				
		
		
		
		return false;
	}

}
