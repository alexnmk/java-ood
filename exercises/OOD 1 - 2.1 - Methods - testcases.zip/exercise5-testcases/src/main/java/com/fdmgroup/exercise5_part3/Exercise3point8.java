package com.fdmgroup.exercise5_part3;

public class Exercise3point8 {

	public double medianNumber(double[] numbers) {
		
		return 0;
	}

}
