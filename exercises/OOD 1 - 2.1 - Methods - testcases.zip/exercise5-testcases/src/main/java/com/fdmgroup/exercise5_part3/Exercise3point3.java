package com.fdmgroup.exercise5_part3;

public class Exercise3point3 {

	public int arrayFrequency(int[] array, int number) {
	
		return 0;
	}

}
