package com.fdmgroup.exercise5_part3;

public class Exercise3point5 {

	public int[] extractEvenArray(int[] array) {

		return null;
	}

}
