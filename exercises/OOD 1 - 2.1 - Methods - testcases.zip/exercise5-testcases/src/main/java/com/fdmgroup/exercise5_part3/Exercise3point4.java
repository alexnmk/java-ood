package com.fdmgroup.exercise5_part3;

public class Exercise3point4 {

	public int maxNumber(int[] array) {

		return 0;
	}

}
  